from mapcrawler.core.scope import ScopePolicy, normalize_url, registrable_domain


def test_normalize_url_removes_fragment_and_tracking():
    assert normalize_url("HTTPS://Example.COM/a/../b/?utm_source=x&z=2&a=1#fragment") == "https://example.com/b/?z=2&a=1"


def test_normalize_relative_url():
    assert normalize_url("../api/users", "https://example.com/app/page") == "https://example.com/api/users"


def test_scope_host_only():
    policy = ScopePolicy("https://app.example.co.uk", include_subdomains=False)
    assert policy.contains("https://app.example.co.uk/api")
    assert not policy.contains("https://cdn.example.co.uk/a.js")


def test_scope_subdomains():
    policy = ScopePolicy("https://app.example.com", include_subdomains=True)
    assert policy.contains("https://api.example.com/v1")
    assert not policy.contains("https://example.net")


def test_registrable_domain_ip():
    assert registrable_domain("127.0.0.1") == "127.0.0.1"


def test_scope_rejects_other_custom_port():
    policy = ScopePolicy("http://127.0.0.1:9001", include_subdomains=False)
    assert policy.contains("http://127.0.0.1:9001/app")
    assert not policy.contains("http://127.0.0.1:8080/admin")


def test_scope_allows_standard_http_to_https_upgrade():
    policy = ScopePolicy("http://example.com", include_subdomains=False)
    assert policy.contains("https://example.com/account")


def test_invalid_port_is_rejected():
    assert normalize_url("http://example.com:invalid/") is None
