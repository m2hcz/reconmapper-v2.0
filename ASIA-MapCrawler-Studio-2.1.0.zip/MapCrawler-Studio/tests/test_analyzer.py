import pytest

from mapcrawler.core.analyzer import PassiveAnalyzer, redact_secret
from mapcrawler.core.models import Artifact, FetchResult, Finding


@pytest.mark.asyncio
async def test_html_mapping_without_submitting_forms():
    artifacts: list[Artifact] = []
    findings: list[Finding] = []
    enqueued: list[tuple[str, int, str]] = []

    async def add_artifact(item: Artifact):
        artifacts.append(item)

    async def add_finding(item: Finding):
        findings.append(item)

    async def enqueue(url: str, depth: int, source: str):
        enqueued.append((url, depth, source))

    analyzer = PassiveAnalyzer(add_artifact, add_finding, enqueue)
    response = FetchResult(
        requested_url="https://example.com/",
        final_url="https://example.com/",
        method="GET",
        status=200,
        content_type="text/html",
        headers={"Content-Type": "text/html"},
        set_cookies=[],
        body='''<html><title>Demo</title><a href="/account">Account</a>
        <form action="/login" method="POST"><input name="username"></form></html>''',
        body_size=150,
        elapsed_ms=10,
    )
    title = await analyzer.analyze(response, 0)
    assert title == "Demo"
    assert any(item.category == "form" and item.value == "POST https://example.com/login" for item in artifacts)
    assert ("https://example.com/account", 1, "https://example.com/") in enqueued
    assert not any(url == "https://example.com/login" for url, _, _ in enqueued)


def test_secret_redaction_is_non_reversible_preview():
    output = redact_secret("abcdefghijklmnopqrstuvwxyz")
    assert "abcdefghijklmnopqrstuvwxyz" not in output
    assert "sha256:" in output


@pytest.mark.asyncio
async def test_template_routes_are_catalogued_but_not_requested():
    artifacts: list[Artifact] = []
    findings: list[Finding] = []
    enqueued: list[tuple[str, int, str]] = []

    async def add_artifact(item: Artifact):
        artifacts.append(item)

    async def add_finding(item: Finding):
        findings.append(item)

    async def enqueue(url: str, depth: int, source: str):
        enqueued.append((url, depth, source))

    analyzer = PassiveAnalyzer(add_artifact, add_finding, enqueue)
    await analyzer._text("https://example.com/app.js", 'const route = "/api/users/{id}";', 0)
    assert any(item.category == "api_endpoint" for item in artifacts)
    assert not enqueued


@pytest.mark.asyncio
async def test_overlapping_secret_signatures_are_deduplicated():
    artifacts: list[Artifact] = []
    findings: list[Finding] = []

    async def add_artifact(item: Artifact):
        artifacts.append(item)

    async def add_finding(item: Finding):
        findings.append(item)

    async def enqueue(url: str, depth: int, source: str):
        pass

    analyzer = PassiveAnalyzer(add_artifact, add_finding, enqueue)
    token = "ghp_abcdefghijklmnopqrstuvwxyzABCDEFGHIJ"
    await analyzer._text("https://example.com/app.js", f'const token = "{token}";', 0)
    assert len(findings) == 1
    assert findings[0].title.startswith("Potential GitHub token")
