"use strict";

const state = {
  scanId: null,
  scan: null,
  websocket: null,
  requests: [],
  findings: [],
  selectedRequestId: null,
  mapRefreshTimer: null,
  pollingTimer: null,
  authorizationResolver: null,
};

const $ = (id) => document.getElementById(id);
const els = {
  target: $("target"),
  recentScans: $("recentScans"),
  settingsBtn: $("settingsBtn"),
  settingsPanel: $("settingsPanel"),
  settingsClose: $("settingsClose"),
  startBtn: $("startBtn"),
  stopBtn: $("stopBtn"),
  exportBtn: $("exportBtn"),
  refreshMap: $("refreshMap"),
  refreshHistory: $("refreshHistory"),
  historySearch: $("historySearch"),
  statusFilter: $("statusFilter"),
  historyBody: $("historyBody"),
  historyCount: $("historyCount"),
  sitemap: $("sitemap"),
  mapCount: $("mapCount"),
  findingsList: $("findingsList"),
  findingBadge: $("findingBadge"),
  statusDot: $("statusDot"),
  statusText: $("statusText"),
  scanIdLabel: $("scanIdLabel"),
  connectionState: $("connectionState"),
  connectionLabel: $("connectionLabel"),
  toast: $("toast"),
  inspectorTitle: $("inspectorTitle"),
  inspectorMethod: $("inspectorMethod"),
  inspectorStatus: $("inspectorStatus"),
  inspectorUrl: $("inspectorUrl"),
  requestTab: $("requestTab"),
  responseTab: $("responseTab"),
  bodyTab: $("bodyTab"),
  metaTab: $("metaTab"),
  metricDiscovered: $("metricDiscovered"),
  metricProcessed: $("metricProcessed"),
  metricFailed: $("metricFailed"),
  metricQueue: $("metricQueue"),
  metricFindings: $("metricFindings"),
  metricDuration: $("metricDuration"),
  workspace: $("workspace"),
  leftPanel: $("leftPanel"),
  rightPanel: $("rightPanel"),
  leftSplitter: $("leftSplitter"),
  rightSplitter: $("rightSplitter"),
  toggleLeftPanel: $("toggleLeftPanel"),
  toggleRightPanel: $("toggleRightPanel"),
  authModal: $("authModal"),
  authTarget: $("authTarget"),
  authorizationCheck: $("authorizationCheck"),
  authConfirm: $("authConfirm"),
  authCancel: $("authCancel"),
  systemClock: $("systemClock"),
};

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>'"]/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;",
  })[char]);
}

function toast(message, type = "") {
  els.toast.textContent = message;
  els.toast.className = `toast visible ${type}`;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => { els.toast.className = "toast"; }, 3600);
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });
  if (!response.ok) {
    let message = `HTTP ${response.status}`;
    try {
      const data = await response.json();
      message = data.detail || message;
    } catch (_) {}
    throw new Error(message);
  }
  const contentType = response.headers.get("content-type") || "";
  return contentType.includes("application/json") ? response.json() : response.text();
}

function setConnection(online, label = "LOCAL") {
  els.connectionState.className = `connection-state ${online ? "online" : "offline"}`;
  els.connectionState.lastChild.textContent = label;
  els.connectionLabel.textContent = online ? "API ONLINE" : "API STANDBY";
}

async function checkHealth() {
  try {
    await api("/api/health");
    setConnection(true, "LOCAL");
  } catch (_) {
    setConnection(false, "OFFLINE");
  }
}

function scanPayload() {
  let customHeaders = {};
  const rawHeaders = $("customHeaders").value.trim();
  if (rawHeaders) {
    customHeaders = JSON.parse(rawHeaders);
    if (!customHeaders || Array.isArray(customHeaders) || typeof customHeaders !== "object") {
      throw new Error("Headers adicionais devem ser um objeto JSON.");
    }
  }
  return {
    target: els.target.value.trim(),
    max_depth: Number($("maxDepth").value),
    concurrency: Number($("concurrency").value),
    max_urls: Number($("maxUrls").value),
    timeout_seconds: Number($("timeoutSeconds").value),
    delay_ms: Number($("delayMs").value),
    max_body_bytes: Number($("maxBodyBytes").value),
    include_subdomains: $("includeSubdomains").checked,
    include_assets: $("includeAssets").checked,
    verify_tls: $("verifyTls").checked,
    probe_metadata: $("probeMetadata").checked,
    custom_headers: customHeaders,
  };
}

function openAuthorization(target) {
  els.authTarget.textContent = target;
  els.authorizationCheck.checked = false;
  els.authConfirm.disabled = true;
  els.authModal.classList.remove("hidden");
  requestAnimationFrame(() => els.authorizationCheck.focus());
  return new Promise((resolve) => { state.authorizationResolver = resolve; });
}

function closeAuthorization(confirmed) {
  els.authModal.classList.add("hidden");
  if (state.authorizationResolver) {
    state.authorizationResolver(confirmed);
    state.authorizationResolver = null;
  }
}

async function startScan() {
  try {
    const payload = scanPayload();
    if (!payload.target) throw new Error("Informe a URL da aplicação.");
    let parsed;
    try { parsed = new URL(payload.target); } catch (_) { throw new Error("Informe uma URL HTTP ou HTTPS válida."); }
    if (!["http:", "https:"].includes(parsed.protocol)) throw new Error("O alvo deve usar HTTP ou HTTPS.");

    const authorized = await openAuthorization(payload.target);
    if (!authorized) return;

    els.startBtn.disabled = true;
    const result = await api("/api/scans", { method: "POST", body: JSON.stringify(payload) });
    closeSettings();
    await selectScan(result.scan_id);
    toast("Operação iniciada. Telemetria em tempo real conectada.");
  } catch (error) {
    toast(error.message, "error");
  } finally {
    els.startBtn.disabled = false;
  }
}

async function stopScan() {
  if (!state.scanId) return;
  try {
    await api(`/api/scans/${state.scanId}/stop`, { method: "POST" });
    toast("Solicitação de parada enviada aos workers.");
  } catch (error) {
    toast(error.message, "error");
  }
}

async function loadRecentScans() {
  try {
    const scans = await api("/api/scans?limit=50");
    els.recentScans.innerHTML = '<option value="">Recentes</option>' + scans.map((scan) => {
      const host = (() => { try { return new URL(scan.target).host; } catch (_) { return scan.target; } })();
      return `<option value="${escapeHtml(scan.id)}">${escapeHtml(host)} · ${escapeHtml(scan.status)}</option>`;
    }).join("");
    if (state.scanId) els.recentScans.value = state.scanId;
  } catch (error) {
    console.error(error);
  }
}

async function selectScan(scanId) {
  state.scanId = scanId;
  state.selectedRequestId = null;
  if (state.websocket) state.websocket.close();
  clearInterval(state.pollingTimer);
  resetInspector();

  try {
    state.scan = await api(`/api/scans/${scanId}`);
    els.target.value = state.scan.target;
    els.exportBtn.href = `/api/scans/${scanId}/export.json`;
    els.exportBtn.classList.remove("disabled");
    renderScanState(state.scan);
    await Promise.all([loadHistory(), loadSitemap(), loadFindings()]);
    connectWebSocket(scanId);
    state.pollingTimer = setInterval(refreshSnapshot, 2500);
    await loadRecentScans();
  } catch (error) {
    toast(error.message, "error");
  }
}

async function refreshSnapshot() {
  if (!state.scanId) return;
  try {
    const scan = await api(`/api/scans/${state.scanId}`);
    state.scan = scan;
    renderScanState(scan);
    if (["completed", "failed", "stopped"].includes(scan.status)) clearInterval(state.pollingTimer);
  } catch (_) {}
}

function formatDurationFromScan(scan) {
  if (!scan) return "00:00:00";
  const startRaw = scan.started_at || scan.created_at;
  if (!startRaw) return "00:00:00";
  const start = new Date(startRaw).getTime();
  const end = scan.finished_at ? new Date(scan.finished_at).getTime() : Date.now();
  if (!Number.isFinite(start) || !Number.isFinite(end)) return "00:00:00";
  const seconds = Math.max(0, Math.floor((end - start) / 1000));
  const hours = String(Math.floor(seconds / 3600)).padStart(2, "0");
  const minutes = String(Math.floor((seconds % 3600) / 60)).padStart(2, "0");
  const secs = String(seconds % 60).padStart(2, "0");
  return `${hours}:${minutes}:${secs}`;
}

function renderScanState(scan) {
  const status = scan.status || "idle";
  els.statusDot.className = `status-dot ${status}`;
  const labels = {
    created: "Preparando operação",
    running: "Mapeamento em execução",
    stopping: "Encerrando workers",
    stopped: "Mapeamento interrompido",
    completed: "Mapeamento concluído",
    failed: "Falha no mapeamento",
  };
  const host = (() => { try { return new URL(scan.target).host; } catch (_) { return scan.target; } })();
  els.statusText.textContent = `${labels[status] || status} · ${host}`;
  els.scanIdLabel.textContent = String(scan.id || state.scanId || "—").slice(0, 12);
  els.metricDiscovered.textContent = Number(scan.discovered || 0).toLocaleString("pt-BR");
  els.metricProcessed.textContent = Number(scan.processed || 0).toLocaleString("pt-BR");
  els.metricFailed.textContent = Number(scan.failed || 0).toLocaleString("pt-BR");
  els.metricQueue.textContent = Number(scan.queue_size || 0).toLocaleString("pt-BR");
  els.metricDuration.textContent = formatDurationFromScan(scan);
  els.stopBtn.disabled = !["created", "running", "stopping"].includes(status) || status === "stopping";
  document.title = `${host} // A.S.I.A MapCrawler`;
}

function connectWebSocket(scanId) {
  const protocol = location.protocol === "https:" ? "wss" : "ws";
  const ws = new WebSocket(`${protocol}://${location.host}/ws/scans/${scanId}`);
  state.websocket = ws;

  ws.onopen = () => setConnection(true, "LIVE");
  ws.onmessage = (message) => {
    const event = JSON.parse(message.data);
    if (event.type === "snapshot" && event.scan) {
      state.scan = { ...(state.scan || {}), ...event.scan };
      renderScanState(state.scan);
    } else if (event.type === "stats") {
      Object.assign(state.scan || {}, event.stats);
      if (state.scan) renderScanState(state.scan);
    } else if (event.type === "status") {
      if (state.scan) {
        state.scan.status = event.status;
        renderScanState(state.scan);
      }
      if (["completed", "failed", "stopped"].includes(event.status)) {
        Promise.all([loadHistory(), loadSitemap(), loadFindings(), loadRecentScans()]);
      }
    } else if (event.type === "request") {
      prependRequest(event.request);
    } else if (event.type === "finding") {
      scheduleFindingsRefresh();
    } else if (event.type === "artifact") {
      scheduleMapRefresh();
    }
  };
  ws.onerror = () => console.debug("WebSocket indisponível; polling permanece ativo.");
  ws.onclose = () => setConnection(true, "POLL");
}

function scheduleMapRefresh() {
  clearTimeout(state.mapRefreshTimer);
  state.mapRefreshTimer = setTimeout(loadSitemap, 800);
}

function scheduleFindingsRefresh() {
  clearTimeout(scheduleFindingsRefresh.timer);
  scheduleFindingsRefresh.timer = setTimeout(loadFindings, 450);
}

async function loadHistory() {
  if (!state.scanId) return;
  try {
    const search = encodeURIComponent(els.historySearch.value.trim());
    const status = els.statusFilter.value ? `&status=${els.statusFilter.value}` : "";
    state.requests = await api(`/api/scans/${state.scanId}/requests?limit=1000&search=${search}${status}`);
    renderHistory();
  } catch (error) {
    toast(error.message, "error");
  }
}

function prependRequest(request) {
  const search = els.historySearch.value.trim().toLowerCase();
  const selectedStatus = els.statusFilter.value;
  if (search && !`${request.url} ${request.content_type}`.toLowerCase().includes(search)) return;
  if (selectedStatus && String(request.status) !== selectedStatus) return;
  state.requests.unshift({
    id: request.id,
    method: request.method,
    final_url: request.url,
    status: request.status,
    content_type: request.content_type,
    body_size: request.body_size,
    elapsed_ms: request.elapsed_ms,
    depth: request.depth,
    title: request.title,
    error: request.error,
  });
  if (state.requests.length > 1000) state.requests.pop();
  renderHistory();
}

function formatBytes(bytes) {
  const value = Number(bytes || 0);
  if (value < 1024) return `${value} B`;
  if (value < 1024 ** 2) return `${(value / 1024).toFixed(1)} KB`;
  return `${(value / 1024 ** 2).toFixed(1)} MB`;
}

function parseUrl(raw) {
  try { return new URL(raw); } catch (_) { return { host: "—", pathname: raw || "—", search: "" }; }
}

function renderHistory() {
  els.historyCount.textContent = `${state.requests.length.toLocaleString("pt-BR")} requests`;
  if (!state.requests.length) {
    els.historyBody.innerHTML = '<tr><td colspan="8" class="table-empty"><span>Nenhuma requisição capturada.</span></td></tr>';
    return;
  }
  els.historyBody.innerHTML = state.requests.map((item) => {
    const url = parseUrl(item.final_url || item.url);
    const family = Math.floor(Number(item.status || 0) / 100);
    const selected = Number(item.id) === Number(state.selectedRequestId) ? "selected" : "";
    return `<tr class="${selected}" data-request-id="${Number(item.id)}">
      <td>${Number(item.id)}</td>
      <td><span class="method">${escapeHtml(item.method || "GET")}</span></td>
      <td title="${escapeHtml(url.host)}">${escapeHtml(url.host)}</td>
      <td title="${escapeHtml(url.pathname + url.search)}">${escapeHtml(url.pathname + url.search)}</td>
      <td><span class="status-code status-${family}">${Number(item.status || 0)}</span></td>
      <td title="${escapeHtml(item.content_type || "")}">${escapeHtml(item.content_type || "—")}</td>
      <td>${formatBytes(item.body_size)}</td>
      <td>${Number(item.elapsed_ms || 0)} ms</td>
    </tr>`;
  }).join("");
  els.historyBody.querySelectorAll("tr[data-request-id]").forEach((row) => {
    row.addEventListener("click", () => selectRequest(Number(row.dataset.requestId)));
  });
}

async function selectRequest(requestId) {
  if (!state.scanId) return;
  state.selectedRequestId = requestId;
  renderHistory();
  try {
    const item = await api(`/api/scans/${state.scanId}/requests/${requestId}`);
    renderInspector(item);
  } catch (error) {
    toast(error.message, "error");
  }
}

function navigateRequest(direction) {
  if (!state.requests.length) return;
  let index = state.requests.findIndex((item) => Number(item.id) === Number(state.selectedRequestId));
  if (index < 0) index = direction > 0 ? -1 : 0;
  const next = Math.max(0, Math.min(state.requests.length - 1, index + direction));
  selectRequest(Number(state.requests[next].id));
  requestAnimationFrame(() => {
    els.historyBody.querySelector(`tr[data-request-id="${state.requests[next].id}"]`)?.scrollIntoView({ block: "nearest" });
  });
}

function headersToText(headers) {
  return Object.entries(headers || {}).map(([name, value]) => `${name}: ${value}`).join("\n");
}

function setInspectorContext(method, status, url, family = "") {
  els.inspectorMethod.textContent = method || "—";
  els.inspectorMethod.className = `context-method ${method && method !== "—" ? "active" : ""}`;
  els.inspectorStatus.textContent = status || "NO SELECTION";
  els.inspectorStatus.className = `context-status ${family ? `status-${family}` : ""}`;
  els.inspectorUrl.textContent = url || "Selecione uma linha no histórico ou um achado.";
  els.inspectorUrl.title = url || "";
}

function resetInspector() {
  els.inspectorTitle.textContent = "Selecione uma requisição";
  setInspectorContext("—", "NO SELECTION", "Selecione uma linha no histórico ou um achado.");
  els.requestTab.textContent = "A requisição selecionada será exibida aqui.";
  els.responseTab.textContent = "A resposta selecionada será exibida aqui.";
  els.bodyTab.textContent = "O preview textual do corpo será exibido aqui.";
  els.metaTab.innerHTML = "";
}

function renderInspector(item) {
  const requested = parseUrl(item.requested_url);
  const requestLine = `${item.method} ${requested.pathname}${requested.search || ""} HTTP/1.1`;
  const requestHeaders = { Host: requested.host, ...(item.request_headers || {}) };
  els.requestTab.textContent = `${requestLine}\n${headersToText(requestHeaders)}`;

  const statusText = item.status === 0 ? "NETWORK ERROR" : "";
  els.responseTab.textContent = `HTTP/1.1 ${item.status} ${statusText}\n${headersToText(item.response_headers || {})}`;
  els.bodyTab.textContent = item.body_preview || item.error || "Resposta sem preview textual.";
  els.inspectorTitle.textContent = `#${item.id} · ${item.method} ${requested.pathname}`;
  setInspectorContext(item.method, item.status === 0 ? "NETWORK ERROR" : `HTTP ${item.status}`, item.final_url || item.requested_url, Math.floor(Number(item.status || 0) / 100));

  const meta = {
    "Requested URL": item.requested_url,
    "Final URL": item.final_url,
    "Status": item.status,
    "MIME": item.content_type || "—",
    "Body size": formatBytes(item.body_size),
    "Elapsed": `${item.elapsed_ms} ms`,
    "Depth": item.depth,
    "Source": item.source,
    "Title": item.title || "—",
    "Redirect chain": (item.redirect_chain || []).join(" → ") || "—",
    "Error": item.error || "—",
  };
  els.metaTab.innerHTML = Object.entries(meta).map(([key, value]) =>
    `<div class="meta-item"><span>${escapeHtml(key)}</span><span>${escapeHtml(value)}</span></div>`
  ).join("");
}

function countTreeNodes(nodes) {
  return (nodes || []).reduce((total, node) => total + 1 + countTreeNodes(node.children), 0);
}

async function loadSitemap() {
  if (!state.scanId) return;
  try {
    const map = await api(`/api/scans/${state.scanId}/sitemap`);
    const hostCount = map.hosts.length;
    const nodeCount = countTreeNodes(map.hosts);
    els.mapCount.textContent = `${hostCount} host${hostCount === 1 ? "" : "s"} · ${nodeCount} nodes`;
    if (!map.hosts.length) {
      els.sitemap.className = "tree empty-state";
      els.sitemap.innerHTML = '<span class="empty-symbol">⌁</span><strong>Superfície ainda vazia</strong><span>A árvore será preenchida conforme rotas forem descobertas.</span>';
      return;
    }
    els.sitemap.className = "tree";
    els.sitemap.innerHTML = map.hosts.map((node) => treeNode(node, true)).join("");
  } catch (error) {
    console.error(error);
  }
}

function treeNode(node, open = false) {
  const hasChildren = Array.isArray(node.children) && node.children.length > 0;
  const className = `tree-${escapeHtml(node.type)}`;
  if (!hasChildren) {
    return `<details class="${className}"><summary title="${escapeHtml(node.name)}">${escapeHtml(node.name)}</summary></details>`;
  }
  return `<details class="${className}" ${open ? "open" : ""}>
    <summary title="${escapeHtml(node.name)}">${escapeHtml(node.name)}</summary>
    ${node.children.map((child) => treeNode(child, false)).join("")}
  </details>`;
}

async function loadFindings() {
  if (!state.scanId) return;
  try {
    const active = document.querySelector(".severity-filter.active");
    const severity = active?.dataset.severity || "";
    const query = severity ? `?severity=${severity}` : "";
    state.findings = await api(`/api/scans/${state.scanId}/findings${query}`);
    renderFindings();
  } catch (error) {
    console.error(error);
  }
}

function renderFindings() {
  els.metricFindings.textContent = state.findings.length.toLocaleString("pt-BR");
  els.findingBadge.textContent = state.findings.length;
  if (!state.findings.length) {
    els.findingsList.className = "findings-list empty-state";
    els.findingsList.innerHTML = '<span class="empty-symbol">◇</span><strong>Nenhum achado</strong><span>Nenhum resultado para o filtro selecionado.</span>';
    return;
  }
  els.findingsList.className = "findings-list";
  els.findingsList.innerHTML = state.findings.map((finding, index) => `
    <article class="finding-card ${escapeHtml(finding.severity)}" data-finding-index="${index}">
      <div class="finding-title">${escapeHtml(finding.title)}</div>
      <div class="finding-meta"><span>${escapeHtml(finding.severity.toUpperCase())}</span><span>${escapeHtml(finding.category)}</span></div>
      <div class="finding-url">${escapeHtml(finding.url)}</div>
    </article>
  `).join("");
  els.findingsList.querySelectorAll("[data-finding-index]").forEach((card) => {
    card.addEventListener("click", () => showFinding(state.findings[Number(card.dataset.findingIndex)]));
  });
}

function activateInspectorTab(name) {
  document.querySelectorAll(".inspector-tab").forEach((tab) => tab.classList.toggle("active", tab.dataset.tab === name));
  document.querySelectorAll(".inspector-pane").forEach((pane) => pane.classList.remove("active"));
  $(`${name}Tab`).classList.add("active");
}

function showFinding(finding) {
  activateInspectorTab("meta");
  els.inspectorTitle.textContent = finding.title;
  setInspectorContext("FINDING", finding.severity.toUpperCase(), finding.url);
  const fields = {
    Severity: finding.severity.toUpperCase(),
    Category: finding.category,
    URL: finding.url,
    Value: finding.value,
    Evidence: finding.evidence || "—",
    Remediation: finding.remediation || "—",
    Detected: finding.created_at,
  };
  els.metaTab.innerHTML = Object.entries(fields).map(([key, value]) =>
    `<div class="meta-item"><span>${escapeHtml(key)}</span><span>${escapeHtml(value)}</span></div>`
  ).join("");
}

function openSettings() {
  els.settingsPanel.classList.remove("hidden");
  els.settingsBtn.setAttribute("aria-expanded", "true");
}

function closeSettings() {
  els.settingsPanel.classList.add("hidden");
  els.settingsBtn.setAttribute("aria-expanded", "false");
}

function toggleSettings() {
  if (els.settingsPanel.classList.contains("hidden")) openSettings();
  else closeSettings();
}

function bindTabs() {
  document.querySelectorAll(".side-tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".side-tab").forEach((item) => item.classList.remove("active"));
      document.querySelectorAll(".side-view").forEach((item) => item.classList.remove("active"));
      tab.classList.add("active");
      $(`${tab.dataset.sideTab}View`).classList.add("active");
    });
  });
  document.querySelectorAll(".inspector-tab").forEach((tab) => {
    tab.addEventListener("click", () => activateInspectorTab(tab.dataset.tab));
  });
  document.querySelectorAll(".severity-filter").forEach((button) => {
    button.addEventListener("click", () => {
      document.querySelectorAll(".severity-filter").forEach((item) => item.classList.remove("active"));
      button.classList.add("active");
      loadFindings();
    });
  });
}

function applyStoredLayout() {
  const left = Number(localStorage.getItem("asia.mapcrawler.leftPanel"));
  const right = Number(localStorage.getItem("asia.mapcrawler.rightPanel"));
  if (Number.isFinite(left) && left >= 220) document.documentElement.style.setProperty("--left-panel", `${left}px`);
  if (Number.isFinite(right) && right >= 320) document.documentElement.style.setProperty("--right-panel", `${right}px`);
  if (localStorage.getItem("asia.mapcrawler.leftCollapsed") === "1") els.workspace.classList.add("left-collapsed");
  if (localStorage.getItem("asia.mapcrawler.rightCollapsed") === "1") els.workspace.classList.add("right-collapsed");
}

function setPanelCollapsed(side, collapsed) {
  const className = `${side}-collapsed`;
  els.workspace.classList.toggle(className, collapsed);
  localStorage.setItem(`asia.mapcrawler.${side}Collapsed`, collapsed ? "1" : "0");
}

function bindPanelControls() {
  els.toggleLeftPanel.addEventListener("click", () => setPanelCollapsed("left", true));
  els.toggleRightPanel.addEventListener("click", () => setPanelCollapsed("right", true));
  els.leftSplitter.addEventListener("dblclick", () => setPanelCollapsed("left", !els.workspace.classList.contains("left-collapsed")));
  els.rightSplitter.addEventListener("dblclick", () => setPanelCollapsed("right", !els.workspace.classList.contains("right-collapsed")));

  const bindResize = (splitter, side) => {
    splitter.addEventListener("pointerdown", (event) => {
      if (els.workspace.classList.contains(`${side}-collapsed`)) {
        setPanelCollapsed(side, false);
        return;
      }
      event.preventDefault();
      splitter.setPointerCapture(event.pointerId);
      splitter.classList.add("active");
      document.body.classList.add("resizing");
      const startX = event.clientX;
      const computed = getComputedStyle(document.documentElement);
      const variable = side === "left" ? "--left-panel" : "--right-panel";
      const startWidth = Number.parseFloat(computed.getPropertyValue(variable)) || (side === "left" ? 320 : 440);

      const onMove = (moveEvent) => {
        const delta = moveEvent.clientX - startX;
        const raw = side === "left" ? startWidth + delta : startWidth - delta;
        const max = side === "left" ? 520 : 720;
        const min = side === "left" ? 220 : 320;
        const width = Math.max(min, Math.min(max, raw));
        document.documentElement.style.setProperty(variable, `${width}px`);
      };
      const onUp = () => {
        splitter.classList.remove("active");
        document.body.classList.remove("resizing");
        splitter.removeEventListener("pointermove", onMove);
        splitter.removeEventListener("pointerup", onUp);
        const width = Number.parseFloat(getComputedStyle(document.documentElement).getPropertyValue(variable));
        localStorage.setItem(`asia.mapcrawler.${side}Panel`, String(Math.round(width)));
      };
      splitter.addEventListener("pointermove", onMove);
      splitter.addEventListener("pointerup", onUp);
    });
  };

  bindResize(els.leftSplitter, "left");
  bindResize(els.rightSplitter, "right");
}

function updateClock() {
  els.systemClock.textContent = new Intl.DateTimeFormat("pt-BR", {
    hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
  }).format(new Date());
  if (state.scan) els.metricDuration.textContent = formatDurationFromScan(state.scan);
}

let historyDebounce;
els.historySearch.addEventListener("input", () => {
  clearTimeout(historyDebounce);
  historyDebounce = setTimeout(loadHistory, 280);
});
els.statusFilter.addEventListener("change", loadHistory);
els.startBtn.addEventListener("click", startScan);
els.stopBtn.addEventListener("click", stopScan);
els.settingsBtn.addEventListener("click", toggleSettings);
els.settingsClose.addEventListener("click", closeSettings);
els.refreshMap.addEventListener("click", loadSitemap);
els.refreshHistory.addEventListener("click", loadHistory);
els.recentScans.addEventListener("change", () => {
  if (els.recentScans.value) selectScan(els.recentScans.value);
});
els.authorizationCheck.addEventListener("change", () => {
  els.authConfirm.disabled = !els.authorizationCheck.checked;
});
els.authConfirm.addEventListener("click", () => closeAuthorization(true));
els.authCancel.addEventListener("click", () => closeAuthorization(false));
els.authModal.querySelector(".modal-backdrop").addEventListener("click", () => closeAuthorization(false));

document.addEventListener("click", (event) => {
  if (els.settingsPanel.classList.contains("hidden")) return;
  if (!els.settingsPanel.contains(event.target) && !els.settingsBtn.contains(event.target)) closeSettings();
});

document.addEventListener("keydown", (event) => {
  const activeTag = document.activeElement?.tagName?.toLowerCase();
  const typing = ["input", "textarea", "select"].includes(activeTag);

  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
    event.preventDefault();
    els.target.focus();
    els.target.select();
  } else if ((event.ctrlKey || event.metaKey) && event.key === ",") {
    event.preventDefault();
    toggleSettings();
  } else if (event.key === "/" && !typing) {
    event.preventDefault();
    els.historySearch.focus();
  } else if (event.key === "Enter" && document.activeElement === els.target) {
    startScan();
  } else if (event.key === "Escape") {
    if (!els.authModal.classList.contains("hidden")) closeAuthorization(false);
    else closeSettings();
  } else if (event.altKey && event.key === "[") {
    event.preventDefault();
    setPanelCollapsed("left", !els.workspace.classList.contains("left-collapsed"));
  } else if (event.altKey && event.key === "]") {
    event.preventDefault();
    setPanelCollapsed("right", !els.workspace.classList.contains("right-collapsed"));
  } else if (!typing && event.key === "ArrowDown") {
    event.preventDefault();
    navigateRequest(1);
  } else if (!typing && event.key === "ArrowUp") {
    event.preventDefault();
    navigateRequest(-1);
  }
});

bindTabs();
applyStoredLayout();
bindPanelControls();
resetInspector();
updateClock();
setInterval(updateClock, 1000);
checkHealth();
setInterval(checkHealth, 30000);
loadRecentScans();
