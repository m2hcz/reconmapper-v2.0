from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field, field_validator


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class ScanStatus(StrEnum):
    CREATED = "created"
    RUNNING = "running"
    STOPPING = "stopping"
    STOPPED = "stopped"
    COMPLETED = "completed"
    FAILED = "failed"


class ScanCreate(BaseModel):
    target: str = Field(min_length=4, max_length=2048)
    max_depth: int = Field(default=4, ge=0, le=12)
    concurrency: int = Field(default=12, ge=1, le=64)
    max_urls: int = Field(default=2500, ge=1, le=100_000)
    timeout_seconds: float = Field(default=15.0, ge=2.0, le=120.0)
    delay_ms: int = Field(default=50, ge=0, le=30_000)
    max_body_bytes: int = Field(default=2_000_000, ge=16_384, le=25_000_000)
    include_subdomains: bool = False
    include_assets: bool = False
    verify_tls: bool = True
    probe_metadata: bool = True
    custom_headers: dict[str, str] = Field(default_factory=dict)

    @field_validator("target")
    @classmethod
    def normalize_target(cls, value: str) -> str:
        value = value.strip()
        if not value.startswith(("http://", "https://")):
            value = "https://" + value
        return value

    @field_validator("custom_headers")
    @classmethod
    def validate_headers(cls, value: dict[str, str]) -> dict[str, str]:
        blocked = {"host", "content-length", "transfer-encoding", "connection"}
        cleaned: dict[str, str] = {}
        for key, item in value.items():
            key = str(key).strip()
            item = str(item).strip()
            if not key or key.lower() in blocked:
                continue
            if "\n" in key or "\r" in key or "\n" in item or "\r" in item:
                raise ValueError("Header names and values cannot contain CR/LF")
            cleaned[key] = item
        return cleaned


@dataclass(slots=True)
class QueueItem:
    url: str
    depth: int
    source: str
    method: str = "GET"


@dataclass(slots=True)
class FetchResult:
    requested_url: str
    final_url: str
    method: str
    status: int
    content_type: str
    headers: dict[str, str]
    set_cookies: list[str]
    body: str
    body_size: int
    elapsed_ms: int
    redirect_chain: list[str] = field(default_factory=list)
    error: str | None = None


@dataclass(slots=True)
class Artifact:
    category: str
    value: str
    source: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class Finding:
    category: str
    severity: str
    title: str
    value: str
    url: str
    evidence: str = ""
    remediation: str = ""
