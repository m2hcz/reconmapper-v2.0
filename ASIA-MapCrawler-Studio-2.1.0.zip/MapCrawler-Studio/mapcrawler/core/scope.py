from __future__ import annotations

import ipaddress
import posixpath
from dataclasses import dataclass, field
from html import unescape
from urllib.parse import parse_qsl, quote, urlencode, urljoin, urlparse, urlunparse

import tldextract

_EXTRACT = tldextract.TLDExtract(suffix_list_urls=None)
_TRACKING_PARAMS = {
    "fbclid", "gclid", "dclid", "msclkid", "mc_cid", "mc_eid", "_ga", "_gl",
}


def normalize_url(raw_url: str, base: str | None = None) -> str | None:
    raw_url = unescape((raw_url or "").strip())
    if not raw_url or raw_url.startswith(("javascript:", "mailto:", "data:", "tel:", "blob:", "#")):
        return None
    if base:
        raw_url = urljoin(base, raw_url)
    elif raw_url.startswith("//"):
        raw_url = "https:" + raw_url

    parsed = urlparse(raw_url)
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.hostname:
        return None
    if parsed.username or parsed.password:
        return None

    scheme = parsed.scheme.lower()
    host = parsed.hostname.lower().rstrip(".")
    try:
        port = parsed.port
    except ValueError:
        return None
    if port and not ((scheme == "http" and port == 80) or (scheme == "https" and port == 443)):
        netloc = f"{host}:{port}"
    else:
        netloc = host

    path = parsed.path or "/"
    trailing = path.endswith("/")
    path = posixpath.normpath(path)
    if not path.startswith("/"):
        path = "/" + path
    if trailing and path != "/":
        path += "/"
    path = quote(path, safe="/%:@!$&'()*+,;=-._~")

    query_items: list[tuple[str, str]] = []
    for key, value in parse_qsl(parsed.query, keep_blank_values=True):
        lowered = key.lower()
        if lowered.startswith("utm_") or lowered in _TRACKING_PARAMS:
            continue
        query_items.append((key, value))
    query = urlencode(query_items, doseq=True)
    return urlunparse((scheme, netloc, path, "", query, ""))


def registrable_domain(host: str) -> str:
    try:
        ipaddress.ip_address(host)
        return host
    except ValueError:
        pass
    result = _EXTRACT(host)
    if result.domain and result.suffix:
        return f"{result.domain}.{result.suffix}".lower()
    return host.lower()


@dataclass(slots=True)
class ScopePolicy:
    seed_url: str
    include_subdomains: bool = False
    seed_host: str = field(init=False)
    seed_domain: str = field(init=False)
    seed_port: int = field(init=False)

    def __post_init__(self) -> None:
        parsed = urlparse(self.seed_url)
        if not parsed.hostname:
            raise ValueError("Target URL has no hostname")
        self.seed_host = parsed.hostname.lower()
        self.seed_domain = registrable_domain(self.seed_host)
        self.seed_port = self._effective_port(parsed)

    @staticmethod
    def _effective_port(parsed) -> int:
        try:
            if parsed.port:
                return parsed.port
        except ValueError:
            return -1
        return 443 if parsed.scheme.lower() == "https" else 80

    def _port_allowed(self, parsed) -> bool:
        port = self._effective_port(parsed)
        if port == self.seed_port:
            return True
        return self.seed_port in {80, 443} and port in {80, 443}

    def contains(self, url: str) -> bool:
        parsed = urlparse(url)
        host = (parsed.hostname or "").lower()
        if not host or not self._port_allowed(parsed):
            return False
        if self.include_subdomains:
            return host == self.seed_domain or host.endswith("." + self.seed_domain)
        return host == self.seed_host

    def classify(self, url: str) -> str:
        parsed = urlparse(url)
        host = (parsed.hostname or "").lower()
        port_allowed = self._port_allowed(parsed)
        if host == self.seed_host:
            return "same_host" if port_allowed else "same_host_other_port"
        if host == self.seed_domain or host.endswith("." + self.seed_domain):
            return "subdomain" if port_allowed else "subdomain_other_port"
        return "external"
