from __future__ import annotations

import asyncio
import hashlib
import json
import re
from pathlib import Path
from typing import Any

import aiosqlite

from .models import Artifact, FetchResult, Finding, ScanCreate, utc_now

SENSITIVE_HEADERS = {"authorization", "proxy-authorization", "cookie", "set-cookie", "x-api-key"}
BODY_SECRET_PATTERNS = [
    re.compile(r"AIza[0-9A-Za-z_-]{35}"),
    re.compile(r"gh[pousr]_[0-9A-Za-z]{36,255}"),
    re.compile(r"xox[baprs]-[0-9A-Za-z-]{10,120}"),
    re.compile(r"AKIA[0-9A-Z]{16}"),
    re.compile(r"-----BEGIN (?:RSA |DSA |EC |OPENSSH |PGP )?PRIVATE KEY-----", re.I),
    re.compile(r"((?:api[_-]?key|access[_-]?token|client[_-]?secret|password|passwd|secret|token)[\"']?\s*[:=]\s*[\"'])([^\"'\r\n]{12,256})([\"'])", re.I),
]


def _fingerprint(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8", errors="ignore")).hexdigest()[:16]


def _redact_headers(headers: dict[str, str]) -> dict[str, str]:
    output: dict[str, str] = {}
    for key, value in headers.items():
        if key.lower() in SENSITIVE_HEADERS:
            output[key] = f"[REDACTED sha256:{_fingerprint(str(value))}]"
        else:
            output[key] = value
    return output


def _redact_body(text: str) -> str:
    redacted = text
    for pattern in BODY_SECRET_PATTERNS:
        if pattern.groups == 3:
            redacted = pattern.sub(
                lambda match: f"{match.group(1)}[REDACTED sha256:{_fingerprint(match.group(2))}]{match.group(3)}",
                redacted,
            )
        else:
            redacted = pattern.sub(
                lambda match: f"[REDACTED sha256:{_fingerprint(match.group(0))}]",
                redacted,
            )
    return redacted


SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS scans (
    id TEXT PRIMARY KEY,
    target TEXT NOT NULL,
    root_host TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL,
    settings_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    started_at TEXT,
    finished_at TEXT,
    processed INTEGER NOT NULL DEFAULT 0,
    failed INTEGER NOT NULL DEFAULT 0,
    skipped INTEGER NOT NULL DEFAULT 0,
    discovered INTEGER NOT NULL DEFAULT 0,
    queue_size INTEGER NOT NULL DEFAULT 0,
    error TEXT
);

CREATE TABLE IF NOT EXISTS requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id TEXT NOT NULL REFERENCES scans(id) ON DELETE CASCADE,
    method TEXT NOT NULL,
    requested_url TEXT NOT NULL,
    final_url TEXT NOT NULL,
    status INTEGER NOT NULL,
    content_type TEXT NOT NULL,
    body_size INTEGER NOT NULL,
    elapsed_ms INTEGER NOT NULL,
    depth INTEGER NOT NULL,
    source TEXT NOT NULL,
    title TEXT NOT NULL DEFAULT '',
    request_headers_json TEXT NOT NULL DEFAULT '{}',
    response_headers_json TEXT NOT NULL DEFAULT '{}',
    redirect_chain_json TEXT NOT NULL DEFAULT '[]',
    body_preview TEXT NOT NULL DEFAULT '',
    error TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_requests_scan_id ON requests(scan_id, id DESC);
CREATE INDEX IF NOT EXISTS idx_requests_url ON requests(scan_id, final_url);

CREATE TABLE IF NOT EXISTS artifacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id TEXT NOT NULL REFERENCES scans(id) ON DELETE CASCADE,
    category TEXT NOT NULL,
    value TEXT NOT NULL,
    source TEXT NOT NULL,
    metadata_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    UNIQUE(scan_id, category, value, source)
);
CREATE INDEX IF NOT EXISTS idx_artifacts_scan_category ON artifacts(scan_id, category, id DESC);

CREATE TABLE IF NOT EXISTS findings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id TEXT NOT NULL REFERENCES scans(id) ON DELETE CASCADE,
    category TEXT NOT NULL,
    severity TEXT NOT NULL,
    title TEXT NOT NULL,
    value TEXT NOT NULL,
    url TEXT NOT NULL,
    evidence TEXT NOT NULL DEFAULT '',
    remediation TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    UNIQUE(scan_id, category, title, value, url)
);
CREATE INDEX IF NOT EXISTS idx_findings_scan_severity ON findings(scan_id, severity, id DESC);
"""


class Storage:
    def __init__(self, path: str | Path):
        self.path = str(path)
        self.db: aiosqlite.Connection | None = None
        self._lock = asyncio.Lock()

    def _connection(self) -> aiosqlite.Connection:
        if self.db is None:
            raise RuntimeError("Storage has not been initialized")
        return self.db

    async def initialize(self) -> None:
        if self.db is not None:
            return
        self.db = await aiosqlite.connect(self.path, isolation_level=None)
        self.db.row_factory = aiosqlite.Row
        await self.db.execute("PRAGMA busy_timeout=5000")
        await self.db.executescript(SCHEMA)

    async def close(self) -> None:
        if self.db is not None:
            await self.db.close()
            self.db = None

    async def create_scan(self, scan_id: str, config: ScanCreate, root_host: str) -> None:
        async with self._lock:
            await self._connection().execute(
                """INSERT INTO scans(id, target, root_host, status, settings_json, created_at)
                   VALUES (?, ?, ?, 'created', ?, ?)""",
                (scan_id, config.target, root_host, config.model_dump_json(), utc_now()),
            )

    async def update_scan(self, scan_id: str, **fields: Any) -> None:
        if not fields:
            return
        allowed = {
            "status", "started_at", "finished_at", "processed", "failed", "skipped",
            "discovered", "queue_size", "error", "root_host",
        }
        pairs = [(key, value) for key, value in fields.items() if key in allowed]
        if not pairs:
            return
        clause = ", ".join(f"{key} = ?" for key, _ in pairs)
        values = [value for _, value in pairs] + [scan_id]
        async with self._lock:
            await self._connection().execute(f"UPDATE scans SET {clause} WHERE id = ?", values)

    async def add_request(
        self,
        scan_id: str,
        result: FetchResult,
        *,
        depth: int,
        source: str,
        title: str,
        request_headers: dict[str, str],
    ) -> int:
        preview = _redact_body(result.body[:16_000])
        stored_request_headers = _redact_headers(request_headers)
        stored_response_headers = _redact_headers(result.headers)
        async with self._lock:
            cursor = await self._connection().execute(
                """INSERT INTO requests(
                    scan_id, method, requested_url, final_url, status, content_type, body_size,
                    elapsed_ms, depth, source, title, request_headers_json,
                    response_headers_json, redirect_chain_json, body_preview, error, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    scan_id, result.method, result.requested_url, result.final_url, result.status,
                    result.content_type, result.body_size, result.elapsed_ms, depth, source, title,
                    json.dumps(stored_request_headers, ensure_ascii=False),
                    json.dumps(stored_response_headers, ensure_ascii=False),
                    json.dumps(result.redirect_chain, ensure_ascii=False),
                    preview, result.error, utc_now(),
                ),
            )
            return int(cursor.lastrowid)

    async def add_artifact(self, scan_id: str, artifact: Artifact) -> bool:
        async with self._lock:
            cursor = await self._connection().execute(
                """INSERT OR IGNORE INTO artifacts(scan_id, category, value, source, metadata_json, created_at)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (
                    scan_id, artifact.category, artifact.value[:5000], artifact.source[:2048],
                    json.dumps(artifact.metadata, ensure_ascii=False), utc_now(),
                ),
            )
            return cursor.rowcount > 0

    async def add_finding(self, scan_id: str, finding: Finding) -> bool:
        async with self._lock:
            cursor = await self._connection().execute(
                """INSERT OR IGNORE INTO findings(
                    scan_id, category, severity, title, value, url, evidence, remediation, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    scan_id, finding.category, finding.severity, finding.title,
                    finding.value[:5000], finding.url[:2048], finding.evidence[:5000],
                    finding.remediation[:5000], utc_now(),
                ),
            )
            return cursor.rowcount > 0

    async def get_scan(self, scan_id: str) -> dict[str, Any] | None:
        async with self._lock:
            cursor = await self._connection().execute("SELECT * FROM scans WHERE id = ?", (scan_id,))
            row = await cursor.fetchone()
            return dict(row) if row else None

    async def list_scans(self, limit: int = 30) -> list[dict[str, Any]]:
        async with self._lock:
            cursor = await self._connection().execute(
                "SELECT * FROM scans ORDER BY created_at DESC LIMIT ?", (limit,)
            )
            rows = await cursor.fetchall()
            return [dict(row) for row in rows]

    async def list_requests(
        self, scan_id: str, *, limit: int = 250, offset: int = 0,
        search: str = "", status: int | None = None,
    ) -> list[dict[str, Any]]:
        clauses = ["scan_id = ?"]
        args: list[Any] = [scan_id]
        if search:
            clauses.append("(final_url LIKE ? OR requested_url LIKE ? OR content_type LIKE ?)")
            token = f"%{search}%"
            args.extend([token, token, token])
        if status is not None:
            clauses.append("status = ?")
            args.append(status)
        args.extend([limit, offset])
        async with self._lock:
            cursor = await self._connection().execute(
                f"""SELECT * FROM requests WHERE {' AND '.join(clauses)}
                    ORDER BY id DESC LIMIT ? OFFSET ?""",
                args,
            )
            rows = await cursor.fetchall()
            return [dict(row) for row in rows]

    async def get_request(self, scan_id: str, request_id: int) -> dict[str, Any] | None:
        async with self._lock:
            cursor = await self._connection().execute(
                "SELECT * FROM requests WHERE scan_id = ? AND id = ?", (scan_id, request_id)
            )
            row = await cursor.fetchone()
            return dict(row) if row else None

    async def list_artifacts(
        self, scan_id: str, *, category: str | None = None, limit: int = 5000,
    ) -> list[dict[str, Any]]:
        query = "SELECT * FROM artifacts WHERE scan_id = ?"
        args: list[Any] = [scan_id]
        if category:
            query += " AND category = ?"
            args.append(category)
        query += " ORDER BY id DESC LIMIT ?"
        args.append(limit)
        async with self._lock:
            cursor = await self._connection().execute(query, args)
            rows = await cursor.fetchall()
            return [dict(row) for row in rows]

    async def list_findings(
        self, scan_id: str, *, severity: str | None = None, limit: int = 2000,
    ) -> list[dict[str, Any]]:
        query = "SELECT * FROM findings WHERE scan_id = ?"
        args: list[Any] = [scan_id]
        if severity:
            query += " AND severity = ?"
            args.append(severity)
        query += " ORDER BY CASE severity WHEN 'high' THEN 1 WHEN 'medium' THEN 2 WHEN 'low' THEN 3 ELSE 4 END, id DESC LIMIT ?"
        args.append(limit)
        async with self._lock:
            cursor = await self._connection().execute(query, args)
            rows = await cursor.fetchall()
            return [dict(row) for row in rows]

    async def export_scan(self, scan_id: str) -> dict[str, Any] | None:
        scan = await self.get_scan(scan_id)
        if not scan:
            return None
        scan["settings"] = json.loads(scan.pop("settings_json"))
        return {
            "tool": "MapCrawler Studio",
            "version": "2.0.0",
            "scan": scan,
            "requests": await self.list_requests(scan_id, limit=100_000),
            "artifacts": await self.list_artifacts(scan_id, limit=100_000),
            "findings": await self.list_findings(scan_id, limit=100_000),
        }
