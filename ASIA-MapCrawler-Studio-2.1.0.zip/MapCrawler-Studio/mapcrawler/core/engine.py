from __future__ import annotations

import asyncio
import json
import random
import time
import uuid
from collections import defaultdict
from contextlib import suppress
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import aiohttp
from aiohttp import ClientSession, ClientTimeout, TCPConnector

from .analyzer import PassiveAnalyzer, is_binary_url
from .models import Artifact, FetchResult, Finding, QueueItem, ScanCreate, ScanStatus, utc_now
from .scope import ScopePolicy, normalize_url
from .storage import Storage

DEFAULT_HEADERS = {
    "Accept": "text/html,application/xhtml+xml,application/json,application/xml;q=0.9,text/plain;q=0.8,*/*;q=0.5",
    "Accept-Language": "en-US,en;q=0.9,pt-BR;q=0.8,pt;q=0.7",
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
    "User-Agent": "MapCrawler-Studio/2.0 (authorized passive web mapper)",
}

METADATA_PATHS = (
    "/robots.txt",
    "/sitemap.xml",
    "/.well-known/security.txt",
    "/manifest.json",
    "/site.webmanifest",
    "/openapi.json",
    "/swagger.json",
)

TEXT_MARKERS = ("text/", "json", "javascript", "xml", "html", "x-www-form-urlencoded", "graphql")


class EventBroker:
    def __init__(self) -> None:
        self._subscribers: dict[str, set[asyncio.Queue[dict[str, Any]]]] = defaultdict(set)
        self._lock = asyncio.Lock()

    async def subscribe(self, scan_id: str) -> asyncio.Queue[dict[str, Any]]:
        queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue(maxsize=1000)
        async with self._lock:
            self._subscribers[scan_id].add(queue)
        return queue

    async def unsubscribe(self, scan_id: str, queue: asyncio.Queue[dict[str, Any]]) -> None:
        async with self._lock:
            self._subscribers[scan_id].discard(queue)
            if not self._subscribers[scan_id]:
                self._subscribers.pop(scan_id, None)

    async def publish(self, scan_id: str, event: dict[str, Any]) -> None:
        event.setdefault("scan_id", scan_id)
        event.setdefault("timestamp", utc_now())
        async with self._lock:
            subscribers = list(self._subscribers.get(scan_id, set()))
        for queue in subscribers:
            if queue.full():
                with suppress(asyncio.QueueEmpty):
                    queue.get_nowait()
            with suppress(asyncio.QueueFull):
                queue.put_nowait(event)


class ScanRunner:
    def __init__(self, scan_id: str, config: ScanCreate, storage: Storage, broker: EventBroker):
        self.scan_id = scan_id
        self.config = config
        self.storage = storage
        self.broker = broker
        self.queue: asyncio.Queue[QueueItem] = asyncio.Queue()
        self.seen: set[str] = set()
        self.seen_lock = asyncio.Lock()
        self.stop_event = asyncio.Event()
        self.session: ClientSession | None = None
        self.scope = ScopePolicy(config.target, config.include_subdomains)
        self.processed = 0
        self.failed = 0
        self.skipped = 0
        self.discovered = 0
        self.last_stats_write = 0.0
        self.request_headers = {**DEFAULT_HEADERS, **config.custom_headers}
        self.analyzer = PassiveAnalyzer(self.emit_artifact, self.emit_finding, self.enqueue)

    async def emit_artifact(self, artifact: Artifact) -> None:
        inserted = await self.storage.add_artifact(self.scan_id, artifact)
        if inserted:
            await self.broker.publish(self.scan_id, {
                "type": "artifact",
                "artifact": {
                    "category": artifact.category,
                    "value": artifact.value,
                    "source": artifact.source,
                    "metadata": artifact.metadata,
                },
            })

    async def emit_finding(self, finding: Finding) -> None:
        inserted = await self.storage.add_finding(self.scan_id, finding)
        if inserted:
            await self.broker.publish(self.scan_id, {
                "type": "finding",
                "finding": {
                    "category": finding.category,
                    "severity": finding.severity,
                    "title": finding.title,
                    "value": finding.value,
                    "url": finding.url,
                },
            })

    async def enqueue(self, raw_url: str, depth: int, source: str) -> None:
        if self.stop_event.is_set() or depth > self.config.max_depth:
            return
        normalized = normalize_url(raw_url, source if source.startswith(("http://", "https://")) else None)
        if not normalized:
            return

        classification = self.scope.classify(normalized)
        await self.emit_artifact(Artifact("endpoint", normalized, source, {"scope": classification, "depth": depth}))
        if not self.scope.contains(normalized):
            await self.emit_artifact(Artifact("external_endpoint", normalized, source, {"scope": classification}))
            return

        if is_binary_url(normalized) and not self.config.include_assets:
            await self.emit_artifact(Artifact("asset", normalized, source, {"fetched": False}))
            return

        async with self.seen_lock:
            if normalized in self.seen:
                return
            if len(self.seen) >= self.config.max_urls:
                self.skipped += 1
                return
            self.seen.add(normalized)
            self.discovered = len(self.seen)
        await self.queue.put(QueueItem(normalized, depth, source))
        await self._stats(force=False)

    async def _stats(self, force: bool = False) -> None:
        now = time.monotonic()
        if not force and now - self.last_stats_write < 0.35:
            return
        self.last_stats_write = now
        data = {
            "processed": self.processed,
            "failed": self.failed,
            "skipped": self.skipped,
            "discovered": self.discovered,
            "queue_size": self.queue.qsize(),
        }
        await self.storage.update_scan(self.scan_id, **data)
        await self.broker.publish(self.scan_id, {"type": "stats", "stats": data})

    async def _fetch(self, item: QueueItem) -> FetchResult:
        assert self.session is not None
        if self.config.delay_ms:
            await asyncio.sleep((self.config.delay_ms / 1000) * random.uniform(0.75, 1.25))

        started = time.perf_counter()
        current_url = item.url
        redirect_chain: list[str] = []
        collected_cookies: list[str] = []
        try:
            for _hop in range(11):
                async with self.session.get(current_url, allow_redirects=False) as response:
                    collected_cookies.extend(response.headers.getall("Set-Cookie", []))
                    location = response.headers.get("Location")
                    if response.status in {301, 302, 303, 307, 308} and location:
                        next_url = normalize_url(location, current_url)
                        if next_url:
                            redirect_chain.append(next_url)
                            if self.scope.contains(next_url):
                                current_url = next_url
                                continue

                    elapsed_ms = int((time.perf_counter() - started) * 1000)
                    content_type = response.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
                    raw = b""
                    if any(marker in content_type for marker in TEXT_MARKERS) or not content_type:
                        raw = await response.content.read(self.config.max_body_bytes + 1)
                    truncated = len(raw) > self.config.max_body_bytes
                    raw = raw[:self.config.max_body_bytes]
                    charset = response.charset or "utf-8"
                    body = raw.decode(charset, errors="replace") if raw else ""
                    headers = {key: value for key, value in response.headers.items()}
                    if truncated:
                        headers["X-MapCrawler-Body-Truncated"] = str(self.config.max_body_bytes)
                    return FetchResult(
                        requested_url=item.url,
                        final_url=current_url,
                        method="GET",
                        status=response.status,
                        content_type=content_type,
                        headers=headers,
                        set_cookies=collected_cookies,
                        body=body,
                        body_size=int(response.headers.get("Content-Length") or len(raw)),
                        elapsed_ms=elapsed_ms,
                        redirect_chain=redirect_chain,
                    )
            raise RuntimeError("Too many redirects")
        except Exception as exc:
            elapsed_ms = int((time.perf_counter() - started) * 1000)
            return FetchResult(
                requested_url=item.url,
                final_url=current_url,
                method="GET",
                status=0,
                content_type="",
                headers={},
                set_cookies=collected_cookies,
                body="",
                body_size=0,
                elapsed_ms=elapsed_ms,
                redirect_chain=redirect_chain,
                error=f"{type(exc).__name__}: {exc}",
            )

    async def worker(self, worker_id: int) -> None:
        while True:
            item = await self.queue.get()
            try:
                if self.stop_event.is_set():
                    self.skipped += 1
                    continue
                result = await self._fetch(item)
                if result.error or result.status == 0 or result.status >= 400:
                    self.failed += 1
                else:
                    self.processed += 1

                title = ""
                final_normalized = normalize_url(result.final_url)
                for redirect_target in result.redirect_chain:
                    if not self.scope.contains(redirect_target):
                        await self.emit_artifact(Artifact(
                            "external_endpoint", redirect_target, item.url,
                            {"kind": "redirect_target", "status": result.status},
                        ))
                if final_normalized and self.scope.contains(final_normalized) and result.body:
                    title = await self.analyzer.analyze(result, item.depth)
                elif final_normalized and not self.scope.contains(final_normalized):
                    await self.emit_artifact(Artifact(
                        "external_endpoint", final_normalized, item.url,
                        {"kind": "redirect_target", "status": result.status},
                    ))

                request_id = await self.storage.add_request(
                    self.scan_id,
                    result,
                    depth=item.depth,
                    source=item.source,
                    title=title,
                    request_headers=self.request_headers,
                )
                await self.broker.publish(self.scan_id, {
                    "type": "request",
                    "request": {
                        "id": request_id,
                        "method": result.method,
                        "url": result.final_url,
                        "status": result.status,
                        "content_type": result.content_type,
                        "body_size": result.body_size,
                        "elapsed_ms": result.elapsed_ms,
                        "depth": item.depth,
                        "title": title,
                        "error": result.error,
                    },
                })
                if result.error:
                    await self.emit_artifact(Artifact("error", result.error, item.url, {"worker": worker_id}))
            except Exception as exc:
                self.failed += 1
                await self.emit_artifact(Artifact("error", f"Worker error: {type(exc).__name__}: {exc}", item.url))
            finally:
                self.queue.task_done()
                await self._stats(force=False)

    async def run(self) -> None:
        await self.storage.update_scan(self.scan_id, status=ScanStatus.RUNNING, started_at=utc_now())
        await self.broker.publish(self.scan_id, {"type": "status", "status": ScanStatus.RUNNING})

        timeout = ClientTimeout(total=self.config.timeout_seconds, connect=min(10, self.config.timeout_seconds))
        connector = TCPConnector(
            limit=max(self.config.concurrency * 2, 20),
            limit_per_host=self.config.concurrency,
            ssl=self.config.verify_tls,
            ttl_dns_cache=300,
            enable_cleanup_closed=True,
        )
        async with ClientSession(
            timeout=timeout,
            connector=connector,
            headers=self.request_headers,
            auto_decompress=True,
            raise_for_status=False,
            cookie_jar=aiohttp.CookieJar(unsafe=True),
        ) as session:
            self.session = session
            await self.enqueue(self.config.target, 0, "seed")
            if self.config.probe_metadata:
                parsed = urlparse(self.config.target)
                root = f"{parsed.scheme}://{parsed.netloc}"
                for path in METADATA_PATHS:
                    await self.enqueue(root + path, 1, "metadata_probe")

            workers = [asyncio.create_task(self.worker(index)) for index in range(self.config.concurrency)]
            await self.queue.join()
            for worker in workers:
                worker.cancel()
            await asyncio.gather(*workers, return_exceptions=True)

        status = ScanStatus.STOPPED if self.stop_event.is_set() else ScanStatus.COMPLETED
        await self._stats(force=True)
        await self.storage.update_scan(self.scan_id, status=status, finished_at=utc_now(), queue_size=0)
        await self.broker.publish(self.scan_id, {"type": "status", "status": status})

    async def stop(self) -> None:
        self.stop_event.set()
        await self.storage.update_scan(self.scan_id, status=ScanStatus.STOPPING)
        await self.broker.publish(self.scan_id, {"type": "status", "status": ScanStatus.STOPPING})


class ScanManager:
    def __init__(self, storage: Storage):
        self.storage = storage
        self.broker = EventBroker()
        self.runners: dict[str, ScanRunner] = {}
        self.tasks: dict[str, asyncio.Task[None]] = {}
        self.lock = asyncio.Lock()

    async def create(self, config: ScanCreate) -> str:
        target = normalize_url(config.target)
        if not target:
            raise ValueError("Target must be a valid HTTP or HTTPS URL")
        config.target = target
        scan_id = uuid.uuid4().hex
        root_host = urlparse(target).hostname or ""
        await self.storage.create_scan(scan_id, config, root_host)
        runner = ScanRunner(scan_id, config, self.storage, self.broker)
        async with self.lock:
            self.runners[scan_id] = runner
            task = asyncio.create_task(self._execute(runner), name=f"scan-{scan_id}")
            self.tasks[scan_id] = task
        return scan_id

    async def _execute(self, runner: ScanRunner) -> None:
        try:
            await runner.run()
        except asyncio.CancelledError:
            await self.storage.update_scan(
                runner.scan_id, status=ScanStatus.STOPPED, finished_at=utc_now(), error="Task cancelled"
            )
            raise
        except Exception as exc:
            await self.storage.update_scan(
                runner.scan_id,
                status=ScanStatus.FAILED,
                finished_at=utc_now(),
                error=f"{type(exc).__name__}: {exc}",
            )
            await self.broker.publish(runner.scan_id, {
                "type": "status", "status": ScanStatus.FAILED, "error": f"{type(exc).__name__}: {exc}"
            })
        finally:
            async with self.lock:
                self.runners.pop(runner.scan_id, None)
                self.tasks.pop(runner.scan_id, None)

    async def stop(self, scan_id: str) -> bool:
        runner = self.runners.get(scan_id)
        if not runner:
            return False
        await runner.stop()
        return True
