from __future__ import annotations

import hashlib
import json
import re
from http.cookies import SimpleCookie
from typing import Awaitable, Callable
from urllib.parse import parse_qsl, urljoin, urlparse

from bs4 import BeautifulSoup, Comment

from .models import Artifact, FetchResult, Finding
from .scope import normalize_url

EmitArtifact = Callable[[Artifact], Awaitable[None]]
EmitFinding = Callable[[Finding], Awaitable[None]]
Enqueue = Callable[[str, int, str], Awaitable[None]]

BINARY_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico", ".woff", ".woff2",
    ".ttf", ".eot", ".mp4", ".mp3", ".pdf", ".zip", ".gz", ".tar", ".rar",
    ".7z", ".webp", ".bmp", ".tiff", ".otf", ".mov", ".avi", ".wmv", ".flv",
    ".iso", ".bin", ".dmg", ".exe", ".msi", ".apk",
}

URL_PATTERN = re.compile(
    r'''(?P<quote>["'`])(?P<url>(?:https?:)?//[^"'`\s<>]+|/(?:[A-Za-z0-9._~!$&()*+,;=:@%{}\[\]-]+/?){1,30}(?:\?[^"'`\s<>]*)?)(?P=quote)''',
    re.IGNORECASE,
)
API_PATTERN = re.compile(
    r'''(?P<quote>["'`])(?P<path>/(?:api|rest|rpc|graphql|ajax|internal|admin|v\d+)(?:/[^"'`\s<>]*)?)(?P=quote)''',
    re.IGNORECASE,
)
WEBSOCKET_PATTERN = re.compile(r'''(?P<quote>["'`])(?P<url>wss?://[^"'`\s<>]+)(?P=quote)''', re.I)
EMAIL_PATTERN = re.compile(r"(?<![\w.+-])[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,63}(?![\w.-])")
CLOUD_PATTERNS = [
    ("AWS S3", re.compile(r"(?:s3://[a-z0-9.-]{3,63}|[a-z0-9.-]{3,63}\.s3(?:[.-][a-z0-9-]+)?\.amazonaws\.com)", re.I)),
    ("Google Cloud Storage", re.compile(r"(?:gs://[a-z0-9._-]{3,222}|storage\.googleapis\.com/[a-z0-9._-]{3,222})", re.I)),
    ("Azure Blob", re.compile(r"[a-z0-9-]{3,63}\.blob\.core\.windows\.net", re.I)),
]
SECRET_PATTERNS = [
    ("Google API key", re.compile(r"AIza[0-9A-Za-z_-]{35}")),
    ("GitHub token", re.compile(r"gh[pousr]_[0-9A-Za-z]{36,255}")),
    ("Slack token", re.compile(r"xox[baprs]-[0-9A-Za-z-]{10,120}")),
    ("AWS access key", re.compile(r"AKIA[0-9A-Z]{16}")),
    ("Private key", re.compile(r"-----BEGIN (?:RSA |DSA |EC |OPENSSH |PGP )?PRIVATE KEY-----", re.I)),
    (
        "Generic credential assignment",
        re.compile(
            r'''(?:api[_-]?key|access[_-]?token|client[_-]?secret|password|passwd|secret|token)["']?\s*[:=]\s*["']([^"'\r\n]{12,256})["']''',
            re.I,
        ),
    ),
]

SECURITY_HEADERS = {
    "strict-transport-security": "Enable HSTS on HTTPS responses with an appropriate max-age.",
    "content-security-policy": "Define a restrictive Content-Security-Policy for browser-delivered content.",
    "x-content-type-options": "Set X-Content-Type-Options: nosniff.",
    "referrer-policy": "Define a Referrer-Policy suitable for the application.",
    "permissions-policy": "Restrict unused browser capabilities with Permissions-Policy.",
}

TECH_MARKERS = {
    "__next_data__": "Next.js",
    "/_next/static/": "Next.js",
    "wp-content/": "WordPress",
    "wp-includes/": "WordPress",
    "__nuxt__": "Nuxt",
    "data-v-": "Vue.js",
    "ng-version=": "Angular",
    "reactroot": "React",
    "swagger-ui": "Swagger UI",
    "graphiql": "GraphiQL",
}


def file_extension(url: str) -> str:
    leaf = urlparse(url).path.rsplit("/", 1)[-1].lower()
    return "." + leaf.rsplit(".", 1)[-1] if "." in leaf else ""


def is_binary_url(url: str) -> bool:
    return file_extension(url) in BINARY_EXTENSIONS


def redact_secret(raw: str) -> str:
    raw = raw.strip()
    digest = hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()[:16]
    if len(raw) <= 10:
        preview = "*" * len(raw)
    else:
        preview = f"{raw[:4]}…{raw[-4:]}"
    return f"{preview} [sha256:{digest}]"


class PassiveAnalyzer:
    def __init__(self, emit_artifact: EmitArtifact, emit_finding: EmitFinding, enqueue: Enqueue):
        self.emit_artifact = emit_artifact
        self.emit_finding = emit_finding
        self.enqueue = enqueue

    async def analyze(self, result: FetchResult, depth: int) -> str:
        await self._headers(result)
        await self._technology(result)
        body = result.body
        if not body:
            return ""

        content_type = result.content_type.lower()
        title = ""
        if "html" in content_type or "<html" in body[:1000].lower():
            title = await self._html(result.final_url, body, depth)
        else:
            await self._text(result.final_url, body, depth)

        path = urlparse(result.final_url).path.lower()
        if path.endswith(("sitemap.xml", ".xml")) or "application/xml" in content_type:
            await self._sitemap(result.final_url, body, depth)
        if path.endswith(("openapi.json", "swagger.json")) or "application/json" in content_type:
            await self._openapi(result.final_url, body, depth)
        if path.endswith("robots.txt"):
            await self._robots(result.final_url, body, depth)
        return title

    async def _headers(self, result: FetchResult) -> None:
        lower = {key.lower(): value for key, value in result.headers.items()}
        if result.final_url.startswith("https://") and result.status < 400:
            for header, remediation in SECURITY_HEADERS.items():
                if header not in lower:
                    await self.emit_finding(Finding(
                        category="security_headers",
                        severity="low",
                        title=f"Missing {header}",
                        value=header,
                        url=result.final_url,
                        evidence=f"HTTP {result.status} response did not contain {header}.",
                        remediation=remediation,
                    ))

        csp = lower.get("content-security-policy", "")
        weak_directives = [item for item in ("'unsafe-inline'", "'unsafe-eval'", "*") if item in csp]
        if csp and weak_directives:
            await self.emit_finding(Finding(
                category="security_headers",
                severity="low",
                title="Potentially permissive Content-Security-Policy",
                value=", ".join(weak_directives),
                url=result.final_url,
                evidence=csp[:1200],
                remediation="Remove broad sources and unsafe directives where application compatibility permits.",
            ))

        for raw_cookie in result.set_cookies:
            cookie = SimpleCookie()
            try:
                cookie.load(raw_cookie)
            except Exception:
                cookie = SimpleCookie()
            names = list(cookie.keys()) or [raw_cookie.split("=", 1)[0].strip()]
            flags = raw_cookie.lower()
            for name in names:
                issues: list[str] = []
                morsel = cookie.get(name)
                has_secure = bool(morsel["secure"]) if morsel else "secure" in flags
                has_httponly = bool(morsel["httponly"]) if morsel else "httponly" in flags
                has_samesite = bool(morsel["samesite"]) if morsel else "samesite" in flags
                if result.final_url.startswith("https://") and not has_secure:
                    issues.append("Secure")
                if not has_httponly:
                    issues.append("HttpOnly")
                if not has_samesite:
                    issues.append("SameSite")
                await self.emit_artifact(Artifact("cookie", name, result.final_url, {"raw": raw_cookie[:1000]}))
                if issues:
                    await self.emit_finding(Finding(
                        category="cookies",
                        severity="low",
                        title=f"Cookie missing attributes: {name}",
                        value=", ".join(issues),
                        url=result.final_url,
                        evidence=raw_cookie[:1200],
                        remediation=f"Review the cookie and add appropriate {', '.join(issues)} attributes.",
                    ))

    async def _technology(self, result: FetchResult) -> None:
        lower = {key.lower(): value for key, value in result.headers.items()}
        for header in ("server", "x-powered-by", "x-generator", "via"):
            if lower.get(header):
                await self.emit_artifact(Artifact("technology", f"{header}: {lower[header]}", result.final_url))
        body_lower = result.body[:500_000].lower()
        for marker, technology in TECH_MARKERS.items():
            if marker in body_lower:
                await self.emit_artifact(Artifact("technology", technology, result.final_url))

    async def _html(self, url: str, body: str, depth: int) -> str:
        try:
            soup = BeautifulSoup(body, "html.parser")
        except Exception:
            await self._text(url, body, depth)
            return ""

        title = soup.title.get_text(" ", strip=True)[:300] if soup.title else ""
        base_tag = soup.find("base", href=True)
        base_url = normalize_url(base_tag.get("href", ""), url) if base_tag else url
        base_url = base_url or url

        attr_map = {
            "a": ("href", "link"), "link": ("href", "resource"), "script": ("src", "script"),
            "img": ("src", "image"), "iframe": ("src", "iframe"), "source": ("src", "media"),
            "video": ("src", "media"), "audio": ("src", "media"), "embed": ("src", "embed"),
        }
        for tag_name, (attribute, kind) in attr_map.items():
            for tag in soup.find_all(tag_name):
                raw = tag.get(attribute)
                if not raw:
                    continue
                full = normalize_url(raw, base_url)
                if not full:
                    continue
                await self.emit_artifact(Artifact("endpoint", full, url, {"kind": kind, "tag": tag_name}))
                await self.enqueue(full, depth + 1, url)

        for form_index, form in enumerate(soup.find_all("form"), start=1):
            method = (form.get("method") or "GET").upper()
            action = normalize_url(form.get("action") or url, base_url) or url
            enctype = form.get("enctype") or "application/x-www-form-urlencoded"
            fields: list[dict[str, str]] = []
            for element in form.find_all(["input", "textarea", "select", "button"]):
                name = (element.get("name") or element.get("id") or "").strip()
                field_type = (element.get("type") or element.name or "").lower()
                if name:
                    fields.append({"name": name, "type": field_type})
                    await self.emit_artifact(Artifact("parameter", name, url, {"location": "form", "type": field_type}))
            await self.emit_artifact(Artifact(
                "form", f"{method} {action}", url,
                {"index": form_index, "method": method, "action": action, "enctype": enctype, "fields": fields},
            ))
            await self.emit_artifact(Artifact("endpoint", action, url, {"kind": "form_action", "method": method}))
            if method == "GET":
                await self.enqueue(action, depth + 1, url)

        for meta in soup.find_all("meta"):
            name = meta.get("name") or meta.get("property") or meta.get("http-equiv")
            content = meta.get("content")
            if name and content:
                await self.emit_artifact(Artifact("metadata", f"{name}: {content[:1000]}", url))

        for comment in soup.find_all(string=lambda value: isinstance(value, Comment)):
            cleaned = str(comment).strip()
            if 4 < len(cleaned) <= 2000:
                await self.emit_artifact(Artifact("comment", cleaned, url))

        for script in soup.find_all("script"):
            if not script.get("src"):
                text = script.string or script.get_text(" ", strip=False)
                if text:
                    await self._text(url, text[:1_000_000], depth)

        await self._text(url, body, depth, discover_urls=False)
        return title

    async def _text(self, url: str, text: str, depth: int, discover_urls: bool = True) -> None:
        for match in EMAIL_PATTERN.finditer(text):
            await self.emit_artifact(Artifact("email", match.group(0), url))

        for provider, pattern in CLOUD_PATTERNS:
            for match in pattern.finditer(text):
                await self.emit_artifact(Artifact("cloud_storage", match.group(0), url, {"provider": provider}))

        if discover_urls:
            for match in API_PATTERN.finditer(text):
                full = normalize_url(match.group("path"), url)
                if full:
                    await self.emit_artifact(Artifact("api_endpoint", full, url))
                    if not any(marker in match.group("path") for marker in ("{", "}", "${", ":id", ":uuid")):
                        await self.enqueue(full, depth + 1, url)

            for match in WEBSOCKET_PATTERN.finditer(text):
                await self.emit_artifact(Artifact("websocket", match.group("url"), url))

            for match in URL_PATTERN.finditer(text):
                full = normalize_url(match.group("url"), url)
                if full:
                    await self.emit_artifact(Artifact("js_route", full, url))
                    raw_candidate = match.group("url")
                    if not any(marker in raw_candidate for marker in ("{", "}", "${", ":id", ":uuid")):
                        await self.enqueue(full, depth + 1, url)

        seen_secret_fingerprints: set[str] = set()
        for label, pattern in SECRET_PATTERNS:
            for match in pattern.finditer(text):
                raw = match.group(1) if match.lastindex else match.group(0)
                fingerprint = hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()
                if fingerprint in seen_secret_fingerprints:
                    continue
                seen_secret_fingerprints.add(fingerprint)
                redacted = redact_secret(raw)
                await self.emit_artifact(Artifact("potential_secret", f"{label}: {redacted}", url))
                await self.emit_finding(Finding(
                    category="potential_secret",
                    severity="high",
                    title=f"Potential {label} exposed in client-readable content",
                    value=redacted,
                    url=url,
                    evidence="Value was redacted and only a non-reversible fingerprint was stored.",
                    remediation="Validate whether the value is a real credential. Revoke/rotate it and remove it from client-delivered content if confirmed.",
                ))

        for name, _ in parse_qsl(urlparse(url).query, keep_blank_values=True):
            await self.emit_artifact(Artifact("parameter", name, url, {"location": "query"}))

    async def _robots(self, url: str, text: str, depth: int) -> None:
        root = f"{urlparse(url).scheme}://{urlparse(url).netloc}"
        for line in text.splitlines():
            if ":" not in line:
                continue
            directive, value = line.split(":", 1)
            directive = directive.strip().lower()
            value = value.strip()
            if not value:
                continue
            if directive == "sitemap":
                full = normalize_url(value, root)
                if full:
                    await self.emit_artifact(Artifact("sitemap", full, url))
                    await self.enqueue(full, depth + 1, url)
            elif directive in {"allow", "disallow"} and "*" not in value and "$" not in value:
                full = normalize_url(value, root)
                if full:
                    await self.emit_artifact(Artifact("robots_route", full, url, {"directive": directive}))
                    await self.enqueue(full, depth + 1, url)

    async def _sitemap(self, url: str, text: str, depth: int) -> None:
        for raw in re.findall(r"<loc[^>]*>\s*(.*?)\s*</loc>", text, flags=re.I | re.S):
            full = normalize_url(raw.strip(), url)
            if full:
                await self.emit_artifact(Artifact("sitemap", full, url))
                await self.enqueue(full, depth + 1, url)

    async def _openapi(self, url: str, text: str, depth: int) -> None:
        if len(text) > 10_000_000:
            return
        try:
            document = json.loads(text)
        except Exception:
            return
        if not isinstance(document, dict) or not isinstance(document.get("paths"), dict):
            return
        servers = document.get("servers") or []
        bases = [item.get("url") for item in servers if isinstance(item, dict) and item.get("url")]
        bases = bases or [f"{urlparse(url).scheme}://{urlparse(url).netloc}"]
        for path, operations in document["paths"].items():
            if not isinstance(path, str):
                continue
            for base in bases[:10]:
                full = normalize_url(path, urljoin(url, str(base)))
                if not full:
                    continue
                methods = []
                if isinstance(operations, dict):
                    methods = [key.upper() for key in operations.keys() if key.lower() in {"get", "post", "put", "patch", "delete", "options", "head"}]
                await self.emit_artifact(Artifact("api_endpoint", full, url, {"methods": methods, "source": "openapi"}))
                if "GET" in methods and not any(marker in path for marker in ("{", "}", "${", ":id", ":uuid")):
                    await self.enqueue(full, depth + 1, url)
