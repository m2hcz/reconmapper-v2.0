from __future__ import annotations

import argparse
import json
import os
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import urlparse

import uvicorn
from fastapi import FastAPI, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles

from . import __version__
from .core.engine import ScanManager
from .core.models import ScanCreate
from .core.storage import Storage

BASE_DIR = Path(__file__).resolve().parent
WEB_DIR = BASE_DIR / "web"
DB_PATH = Path(os.getenv("MAPCRAWLER_DB", "./mapcrawler.db")).resolve()

storage = Storage(DB_PATH)
manager = ScanManager(storage)


@asynccontextmanager
async def lifespan(_: FastAPI):
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    await storage.initialize()
    try:
        yield
    finally:
        await storage.close()


app = FastAPI(
    title="MapCrawler Studio",
    version=__version__,
    description="Authorized passive web application mapper",
    lifespan=lifespan,
    docs_url="/api/docs",
    redoc_url=None,
)
app.mount("/static", StaticFiles(directory=WEB_DIR / "static"), name="static")


@app.get("/", include_in_schema=False)
async def index() -> FileResponse:
    return FileResponse(WEB_DIR / "templates" / "index.html")


@app.get("/api/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "version": __version__}


@app.post("/api/scans", status_code=202)
async def create_scan(payload: ScanCreate) -> dict[str, str]:
    try:
        scan_id = await manager.create(payload)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return {"scan_id": scan_id, "status": "created"}


@app.get("/api/scans")
async def list_scans(limit: int = Query(default=30, ge=1, le=200)) -> list[dict]:
    return await storage.list_scans(limit)


@app.get("/api/scans/{scan_id}")
async def get_scan(scan_id: str) -> dict:
    scan = await storage.get_scan(scan_id)
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")
    scan["settings"] = json.loads(scan.pop("settings_json"))
    return scan


@app.post("/api/scans/{scan_id}/stop", status_code=202)
async def stop_scan(scan_id: str) -> dict[str, str]:
    scan = await storage.get_scan(scan_id)
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")
    stopped = await manager.stop(scan_id)
    if not stopped:
        return {"scan_id": scan_id, "status": scan["status"]}
    return {"scan_id": scan_id, "status": "stopping"}


@app.get("/api/scans/{scan_id}/requests")
async def list_requests(
    scan_id: str,
    limit: int = Query(default=250, ge=1, le=2000),
    offset: int = Query(default=0, ge=0),
    search: str = Query(default="", max_length=300),
    status: int | None = Query(default=None, ge=0, le=599),
) -> list[dict]:
    return await storage.list_requests(scan_id, limit=limit, offset=offset, search=search, status=status)


@app.get("/api/scans/{scan_id}/requests/{request_id}")
async def get_request(scan_id: str, request_id: int) -> dict:
    item = await storage.get_request(scan_id, request_id)
    if not item:
        raise HTTPException(status_code=404, detail="Request not found")
    for key in ("request_headers_json", "response_headers_json", "redirect_chain_json"):
        parsed_key = key.removesuffix("_json")
        try:
            item[parsed_key] = json.loads(item.pop(key))
        except Exception:
            item[parsed_key] = item.pop(key)
    return item


@app.get("/api/scans/{scan_id}/artifacts")
async def list_artifacts(
    scan_id: str,
    category: str | None = Query(default=None, max_length=80),
    limit: int = Query(default=5000, ge=1, le=100_000),
) -> list[dict]:
    items = await storage.list_artifacts(scan_id, category=category, limit=limit)
    for item in items:
        try:
            item["metadata"] = json.loads(item.pop("metadata_json"))
        except Exception:
            item["metadata"] = item.pop("metadata_json")
    return items


@app.get("/api/scans/{scan_id}/findings")
async def list_findings(
    scan_id: str,
    severity: str | None = Query(default=None, pattern="^(high|medium|low|info)$"),
    limit: int = Query(default=2000, ge=1, le=100_000),
) -> list[dict]:
    return await storage.list_findings(scan_id, severity=severity, limit=limit)


@app.get("/api/scans/{scan_id}/sitemap")
async def sitemap(scan_id: str) -> dict:
    items = await storage.list_artifacts(scan_id, category="endpoint", limit=100_000)
    hosts: dict[str, dict] = {}
    for item in items:
        try:
            parsed = urlparse(item["value"])
            if not parsed.hostname:
                continue
            host = parsed.netloc
            host_node = hosts.setdefault(host, {"name": host, "type": "host", "children": {}})
            current = host_node["children"]
            path_parts = [part for part in parsed.path.split("/") if part]
            if not path_parts:
                path_parts = ["/"]
            for index, part in enumerate(path_parts):
                is_last = index == len(path_parts) - 1
                node_type = "directory" if (not is_last or parsed.path.endswith("/")) else "endpoint"
                key = f"{part}:{node_type}"
                node = current.setdefault(key, {"name": part, "type": node_type, "children": {}})
                current = node["children"]
            if parsed.query:
                current.setdefault(
                    f"?{parsed.query}:query",
                    {"name": f"?{parsed.query}", "type": "query", "children": {}},
                )
        except Exception:
            continue

    def serialize(node: dict) -> dict:
        children = [serialize(child) for child in node.get("children", {}).values()]
        children.sort(key=lambda child: (child["type"] != "directory", child["name"].lower()))
        return {"name": node["name"], "type": node["type"], "children": children}

    return {"hosts": [serialize(node) for node in sorted(hosts.values(), key=lambda item: item["name"])]}


@app.get("/api/scans/{scan_id}/export.json")
async def export_json(scan_id: str) -> Response:
    report = await storage.export_scan(scan_id)
    if not report:
        raise HTTPException(status_code=404, detail="Scan not found")
    payload = json.dumps(report, indent=2, ensure_ascii=False).encode("utf-8")
    return Response(
        payload,
        media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="mapcrawler-{scan_id}.json"'},
    )


@app.websocket("/ws/scans/{scan_id}")
async def scan_events(websocket: WebSocket, scan_id: str) -> None:
    await websocket.accept()
    queue = await manager.broker.subscribe(scan_id)
    try:
        scan = await storage.get_scan(scan_id)
        if scan:
            await websocket.send_json({"type": "snapshot", "scan": scan})
        while True:
            event = await queue.get()
            await websocket.send_json(event)
    except WebSocketDisconnect:
        pass
    finally:
        await manager.broker.unsubscribe(scan_id, queue)


def main() -> None:
    parser = argparse.ArgumentParser(description="MapCrawler Studio local web UI")
    parser.add_argument("--host", default=os.getenv("MAPCRAWLER_HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.getenv("MAPCRAWLER_PORT", "8080")))
    parser.add_argument("--reload", action="store_true")
    args = parser.parse_args()
    uvicorn.run("mapcrawler.app:app", host=args.host, port=args.port, reload=args.reload)


if __name__ == "__main__":
    main()
