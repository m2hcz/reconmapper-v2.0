# A.S.I.A MapCrawler Studio 2.1

A.S.I.A MapCrawler Studio é um mapeador passivo e assíncrono de aplicações web, com interface local inspirada no fluxo de trabalho do Burp Suite. O painel roda por padrão em `http://127.0.0.1:8080` e organiza a superfície descoberta em Site Map, HTTP History, Inspector e Findings.

O projeto foi desenhado para avaliações autorizadas. Ele executa somente requisições `GET`, não envia formulários, não executa brute force, não tenta autenticação e não explora vulnerabilidades. Métodos mutáveis encontrados em HTML ou OpenAPI são apenas catalogados.


## Interface A.S.I.A 2.1

- Identidade visual full-black baseada no design system da A.S.I.A Security.
- Tipografia Space Grotesk, Inter e Space Mono, com fallbacks locais.
- Console operacional com Site Map, Request History e Inspector redimensionáveis.
- Larguras e painéis recolhidos persistidos no navegador.
- Modal de confirmação de autorização integrado ao fluxo de início.
- Indicadores de WebSocket/polling, duração, scan ID e contadores em tempo real.
- Atalhos: `Ctrl+K` para o alvo, `Ctrl+,` para configurações, `/` para busca, `Alt+[` e `Alt+]` para painéis.
- Navegação no histórico com as setas para cima e para baixo.

## Principais melhorias

- Backend modular com FastAPI, aiohttp e WebSocket.
- Persistência em SQLite com WAL; scans anteriores continuam disponíveis após reiniciar o servidor.
- Site Map hierárquico por host, diretório, endpoint e query string.
- HTTP History com status, MIME, tamanho, latência e inspector de request/response/body.
- Descoberta em HTML, JavaScript, JSON, XML, robots.txt, sitemap e OpenAPI.
- Catálogo de links, APIs, formulários, parâmetros, WebSockets, subdomínios, recursos externos, comentários, metadados e tecnologias.
- Verificações passivas de headers e cookies.
- Detecção de possíveis credenciais com redaction em achados, previews persistidos e headers sensíveis, usando fingerprint SHA-256.
- Controles de escopo, profundidade, concorrência, delay, limite de URLs, TLS e tamanho de resposta.
- Exportação completa em JSON.
- Parada cooperativa de scan e atualização ao vivo.

## Instalação no Windows

```powershell
cd MapCrawler-Studio
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python run.py
```

Também é possível iniciar diretamente no Windows com `start_windows.bat` ou no Linux com `./start_linux.sh`.

Abra:

```text
http://127.0.0.1:8080
```

Para permitir acesso a partir de outros dispositivos da rede local, faça isso somente em uma rede confiável:

```powershell
python run.py --host 0.0.0.0 --port 8080
```

## Instalação no Linux/macOS

```bash
cd MapCrawler-Studio
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
python run.py
```

## Docker

```bash
docker build -t mapcrawler-studio .
docker run --rm -p 127.0.0.1:8080:8080 -v "$PWD/data:/app/data" \
  -e MAPCRAWLER_DB=/app/data/mapcrawler.db mapcrawler-studio
```

## Headers de sessão

No painel de configuração, use JSON para fornecer headers de uma sessão de teste autorizada:

```json
{
  "Cookie": "session=YOUR_AUTHORIZED_TEST_SESSION",
  "Authorization": "Bearer YOUR_AUTHORIZED_TEST_TOKEN"
}
```

Os valores são usados durante o scan, mas headers sensíveis são persistidos apenas de forma redigida. Ainda assim, use credenciais de teste e proteja o arquivo `mapcrawler.db`, pois ele contém URLs, metadados e previews de respostas.

## API

A documentação OpenAPI do serviço local fica em:

```text
http://127.0.0.1:8080/api/docs
```

Rotas principais:

- `POST /api/scans`
- `POST /api/scans/{scan_id}/stop`
- `GET /api/scans/{scan_id}/requests`
- `GET /api/scans/{scan_id}/sitemap`
- `GET /api/scans/{scan_id}/findings`
- `GET /api/scans/{scan_id}/export.json`
- `WS /ws/scans/{scan_id}`

## Limitações intencionais

Um crawler não consegue descobrir rotas que dependam exclusivamente de interação humana, estado complexo de frontend, WebSockets autenticados ou navegação em browser real. Para esses casos, a arquitetura já permite uma próxima etapa com importação de HAR ou integração opcional com Playwright, sem alterar o banco e a interface.

## Testes

```bash
pip install -r requirements-dev.txt
python -m pytest -q
```

A suíte cobre escopo por host/porta, normalização de URLs, formulários não enviados, rotas parametrizadas, redaction de dados sensíveis e deduplicação de achados.
