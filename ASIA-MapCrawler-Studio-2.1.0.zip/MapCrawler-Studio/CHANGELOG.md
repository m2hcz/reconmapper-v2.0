# Changelog

## 2.1.0 — A.S.I.A Interface

- Redesign completo da interface no sistema visual A.S.I.A Security.
- Console operacional full-black com grade técnica, ruído sutil e marca geométrica.
- Nova barra de alvo, telemetria, scan ID, duração e estado de conexão.
- Site Map, Request History e Inspector com painéis redimensionáveis e persistência local.
- Painéis laterais recolhíveis por controle, duplo clique no divisor ou atalho.
- Modal próprio para confirmação de autorização antes do scan.
- Configurações reorganizadas por execução, escopo/transporte e sessão autorizada.
- Inspector com contexto de método, status e URL.
- Busca e filtros refinados, estados vazios e feedback visual consistentes.
- Atalhos de produtividade e navegação por teclado.
- Backend, banco, API e modelo passivo preservados sem regressão.
